-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Počítač: 127.0.0.1
-- Vytvořeno: Ned 06. čen 2021, 18:53
-- Verze serveru: 10.4.11-MariaDB
-- Verze PHP: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `pivo`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `pivo`
--

CREATE TABLE `pivo` (
  `id` int(11) NOT NULL,
  `nazev` varchar(45) NOT NULL,
  `chut` varchar(45) NOT NULL,
  `barva` varchar(45) NOT NULL,
  `alkohol` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Vypisuji data pro tabulku `pivo`
--

INSERT INTO `pivo` (`id`, `nazev`, `chut`, `barva`, `alkohol`) VALUES
(1, 'pivson', 'dobrá', 'pivová', 1),
(2, 'pivoň', 'nic moc', 'divná', 1),
(3, 'pivák', 'dá se', 'hezká', 0),
(4, 'pivík', 'super', 'hodně hezká', 1),
(6, 'pejvo', 'mňam', 'žlutá', 0),
(7, 'pejvo', 'super', 'joo', 1);

--
-- Klíče pro exportované tabulky
--

--
-- Klíče pro tabulku `pivo`
--
ALTER TABLE `pivo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `pivo`
--
ALTER TABLE `pivo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

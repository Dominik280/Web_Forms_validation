<?php

namespace App\Controllers;
use App\Models\Model_form;
use CodeIgniter\Controller;

class Form extends BaseController
{

    public function form() {
        return view('form');
    }
 
    public function validation() {
        helper(['form', 'url']);
        
        $input = $this->validate([
            'nazev'			=>	'required',
			'chut'		=>	'required|min_length[3]',
			'barva'	        =>	'required'
        ]);

        $Model_form = new Model_form();
 
        if (!$input) {
            echo view('form', [
                'validation' => $this->validator
            ]);
        } else {
            $Model_form->save([
                "nazev"     =>$this->request->getVar("nazev"),  
                "chut"  =>$this->request->getVar("chut"),
                "barva"     =>$this->request->getVar("barva"),
                "alkohol"     =>$this->request->getVar("alkohol") 
            ]);          

            return $this->response->redirect(site_url('Form/validation'));
        }
    }

}

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Pivo</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <style>
    .container {
      max-width: 550px;
    }
  </style>
</head>

<body>
  <div class="container mt-5">
         
    <?php $validation = \Config\Services::validation(); ?>

    <form method="post" action="<?php echo base_url("/validation"); ?>">
      <div class="form-group">
        <label>Název</label>
        <input type="text" name="nazev" class="form-control">

        <!-- Error -->
        <?php if($validation->getError('nazev')) {?>
            <div class='alert alert-danger mt-2'>
              <?= $error = $validation->getError('nazev'); ?>
            </div>
        <?php }?>
      </div>
       

      <div class="form-group">
        <label>Chuť</label>
        <input type="text" name="chut" class="form-control">

        <!-- Error -->
        <?php if($validation->getError('chut')) {?>
            <div class='alert alert-danger mt-2'>
              <?= $error = $validation->getError('chut'); ?>
            </div>
        <?php }?>
      </div>

      <div class="form-group">
        <label>Barva</label>
        <input type="text" name="barva" class="form-control">

        <!-- Error -->
        <?php if($validation->getError('barva')) {?>
            <div class='alert alert-danger mt-2'>
              <?= $error = $validation->getError('barva'); ?>
            </div>
        <?php }?>
      </div>
                <div class="form-group">   
                    <label>Alkoholické</label>
                    <select name="alkohol"  class="form-control">
                        <option value="1">Ano</option>
                        <option value="0">Ne</option>
                    </select>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-block">Vložit</button>
                </div>
            </div>
         </div>

    </form>

  </div>
</body>

</html>